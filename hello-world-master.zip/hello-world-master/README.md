# hello-world
My first repository

Hi, I'm David
I'm a student studying Computer Science in TU Dublin(Tallaght Campus) and a member of St John Ambulance learning CPR and First Aid
